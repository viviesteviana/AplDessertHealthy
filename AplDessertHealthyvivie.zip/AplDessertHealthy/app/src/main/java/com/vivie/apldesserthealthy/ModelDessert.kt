package com.vivie.apldesserthealthy

class ModelDessert(
    var id: Int = 0,
    var title: String = "",
    var desc: String = "",
    var pembuatan: String = "",
    var img: Int = 0,
) {
}
